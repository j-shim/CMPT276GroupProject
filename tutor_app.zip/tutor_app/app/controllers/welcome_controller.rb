class WelcomeController < ApplicationController
  def index
  end

  def help
  end

  def about
  end

  def contact
  end
end
