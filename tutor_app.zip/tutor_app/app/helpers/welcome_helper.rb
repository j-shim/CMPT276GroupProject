module WelcomeHelper
end
